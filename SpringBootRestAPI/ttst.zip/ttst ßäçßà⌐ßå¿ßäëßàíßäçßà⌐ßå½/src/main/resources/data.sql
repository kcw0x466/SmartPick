INSERT INTO member (id, email, name) VALUES (1, 'test@example.com', '테스트 회원');

