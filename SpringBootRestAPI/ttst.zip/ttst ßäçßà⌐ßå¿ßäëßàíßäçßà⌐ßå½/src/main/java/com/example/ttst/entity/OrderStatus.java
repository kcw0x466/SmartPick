package com.example.ttst.entity;

public enum OrderStatus {
    ORDERED,
    PAiD,
    CANCELLED
}
