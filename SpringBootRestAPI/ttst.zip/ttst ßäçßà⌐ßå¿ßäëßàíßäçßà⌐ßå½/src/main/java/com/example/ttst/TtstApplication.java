package com.example.ttst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TtstApplication {

	public static void main(String[] args) {
		SpringApplication.run(TtstApplication.class, args);
	}

}
