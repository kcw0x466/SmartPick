package com.example.ttst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtstApplicationTests {

	@Test
	void contextLoads() {
	}

}
